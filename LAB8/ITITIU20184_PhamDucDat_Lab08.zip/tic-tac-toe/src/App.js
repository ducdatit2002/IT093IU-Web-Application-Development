import './App.css';
import TicTacToe from './Components/TicTacToe/TicTacToe';

function App() {
  return (
    <div>
      <TicTacToe/>
    </div>
  );
}

export default App;
